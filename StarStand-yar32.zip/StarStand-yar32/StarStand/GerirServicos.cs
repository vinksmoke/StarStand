﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarStand
{
    public partial class GerirServicos : Form
    {
        public GerirServicos()
        {
            InitializeComponent();
        }

        private void BtnAddCarros_Click(object sender, EventArgs e)
        {

        }
    }
}
